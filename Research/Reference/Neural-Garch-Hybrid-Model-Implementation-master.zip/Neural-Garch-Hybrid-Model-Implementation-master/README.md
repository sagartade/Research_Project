# Neural-Garch-Hybrid-Model-Implementation
This study is orginally my final homework of master degree.
Objection of this repository is; by combining GARCH(1,1) and LSTM model implementing predictions.
